a = input()
hoa = 0
thuong = 0
for i in range(len(a)):
    if a[i] >='a' and a[i] <= 'z':
        thuong += 1
    else:
        hoa += 1
if thuong < hoa:
    print(a.upper())
else:
    print(a.lower())