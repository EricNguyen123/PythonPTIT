n = input()
k = int(input())
x = {}
for i in range(0,len(n),2):
    v = n[i:i+2]
    if len(v) == 2:
        if v in x:
            x[v] += 1
        else:
            x[v] = 1
a = list(x.items())
a.sort(key=lambda x: x[0])
d = 0
for i in a:
    if i[1] >= k:
        print(str(i[0]) + " " + str(i[1]))
        d += 1
if d == 0:
    print("NOT FOUND")