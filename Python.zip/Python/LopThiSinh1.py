class ThiSinh:
    def __init__(self , name, dates, a, b, c):
        self.name = name
        self.dates = dates
        self.a = a
        self.b = b
        self.c = c
    def __str__(self):
        res = ""
        res += self.name + " "
        s = self.dates.split("/")
        while len(s[0]) < 2:
            s[0] = "0" + s[0]
        while len(s[1]) < 2:
            s[1] = "0" + s[1]
        while len(s[2]) < 4:
            s[2] = "0" + s[2]
        res += s[0] + "/" + s[1] + "/" + s[2] + " "
        res += "{tong:.1f}".format(tong = self.a + self.b + self.c)
        return res
name = input()
dates = input()
a = float(input())
b = float(input())
c = float(input())
print(ThiSinh(name, dates, a, b, c))