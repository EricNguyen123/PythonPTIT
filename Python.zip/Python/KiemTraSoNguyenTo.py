import math
n = int(input())
while n > 0:
    n -= 1
    s = input()
    m = len(s)
    a = s[m - 4: m]
    a = int(a)
    d = 0
    l = int(math.sqrt(a)) + 1
    for i in range(2, l):
        if a % i == 0:
            d = 1
            break
    if d == 0 and a != 0 and a != 1:
        print("YES")
    else:
        print("NO")
    