t = int(input())
while t > 0:
    t -= 1
    m, n = list(map(int, input().split()))
    s = 0
    b = []
    for i in range(m):
        a = list(map(int, input().split()))
        b.append(a)
        x = 0
        for j in range(n):
            if a[j] == 0:
                continue
            x += a[j] * 4 + 2
            if j >= 1:
                Min = min(a[j], a[j - 1])
                x -= Min * 2
            if i >= 1:
                Min = min(a[j], b[i - 1][j])
                x -= Min * 2
            # print("---")
            # print(x)
        s += x
    print(s)