


# from decimal import ROUND_HALF_UP, Decimal


# class SinhVien:
#     monhoc = []
#     def __init__(self, id, name, monhoc):
#         self.id = id
#         self.name = name
#         self.monhoc = monhoc
#     def __str__(self):
#         res = ""
#         ID = str(self.id)
#         while len(ID) < 2:
#             ID = "0" + ID
#         res += "HS" + ID + " " + self.name + " "
#         diem = ((sum(self.monhoc) + self.monhoc[0] + self.monhoc[1]) / 12)
#         diem = diem.quantize(Decimal('0.1'), ROUND_HALF_UP)
#         res += "{:}".format(diem)
#         if diem < 5: 
#             res += " YEU"
#         elif diem >= 5 and diem < 7:
#             res += " TB"
#         elif diem >= 7 and diem < 8:
#             res += " KHA"
#         elif diem >= 8 and diem < 9:
#             res += " GIOI"
#         else:
#             res += " XUAT SAC"
#         return res
# t = int(input())
# sv = []
# for i in range(0, t):
#     x = input()
#     y = list(map(float, input().split()))
#     sv.append(SinhVien(i + 1, x, y))
# sv.sort(key=lambda x: round((sum(x.monhoc) + x.monhoc[0] + x.monhoc[1]) / 12, 1), reverse=True)
# for i in range(0, t):
#     print(sv[i])
        
from decimal import ROUND_HALF_UP, Decimal

id = 1
class HocSinh :
    maHS = 'HS'
    diemTrungBinh = 0
    xepLoai = ''
    def __init__(self, ten, diem) :
        global id
        self.maHS += '{:02d}'.format(id)
        id += 1
        self.ten = ten
        x = 2 * diem[0] + 2 * diem[1]
        for i in range(2, 10) :
            x += diem[i]
        x /= 12
        if x < 5 : self.xepLoai = 'YEU'
        elif x < 7 : self.xepLoai = 'TB'
        elif x < 8 : self.xepLoai = 'KHA'
        elif x < 9 : self.xepLoai = 'GIOI'
        else : self.xepLoai = 'XUAT SAC'
        self.diemTrungBinh = x.quantize(Decimal('0.1'), ROUND_HALF_UP)

    def output(self) :
        print(self.maHS, self.ten, self.diemTrungBinh, self.xepLoai)

n = int(input())
a = []
for i in range(n) :
    b = input()
    c = [Decimal(x) for x in input().split()]
    a.append(HocSinh(b, c))

a = sorted(a, key= lambda x : (- x.diemTrungBinh, x.maHS))
for i in a :
    i.output()
