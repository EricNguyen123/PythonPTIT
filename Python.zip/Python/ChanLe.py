n = int(input())
while n > 0:
    n -= 1
    a = input()
    l = len(a)
    sum = 0
    d = 0
    for i in range(1, l):
        if int(a[i - 1]) + 2 == int(a[i]) or int(a[i - 1]) - 2 == int(a[i]):
            sum += int(a[i - 1])
        else:
            d = 1
            break
    if d == 1:
        print("NO")
    else:
        if (sum + int(a[l - 1])) % 10 == 0:
            print("YES")
        else:
            print("NO")