
from math import gcd


class PhanSo:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __str__(self):
        ucln = gcd(self.x, self.y)
        return str(int(self.x / ucln)) + "/" + str(int(self.y / ucln))
    def tong(self, z):
        ucln = gcd(self.x, self.y)
        a = int(self.x / ucln)
        b = int(self.y / ucln)
        ucln = gcd(z.x, z.y)
        c = int(z.x / ucln)
        d = int(z.y / ucln)
        a = a * d + b * c
        b = b * d
        return PhanSo(a,b)
a = list(map(int, input().split()))
b = PhanSo(a[0], a[1])
c = PhanSo(a[2], a[3])
print(b.tong(c))
