n = list(map(int, input().split()))
a = list(map(int, input().split()))
b = list(map(int, input().split()))
c = {}
d = {}
for i in a:
    c[i] = 1
for i in b:
    d[i] = 1
x = list(c.keys())
y = list(d.keys())
x.sort()
y.sort()
z = 0
if len(x) == len(y):
    for i in range(len(x)):
        if x[i] != y[i]:
            z = 1
            break
else:
    z = 1
if z == 0:
    print("YES")
else:
    print("NO")