t = int(input())
while t > 0:
    t -= 1
    n = input()
    a = list(map(int, input().split()))
    b = {}
    for i in a:
        if i in b:
            b[i] += 1
        else:
            b[i] = 1
    for i in b:
        if b[i] % 2 != 0:
            print(i)
            break