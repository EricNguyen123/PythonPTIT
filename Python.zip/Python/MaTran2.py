n = int(input())
a = []
for i in range(n):
    a.append(input().split())
k = int(input())

sumup = sumdown = 0

j = n - 1
for i in a:
    for l in range(j + 1, n):
        sumdown += int(i[l])
    for l in range(j):
        sumup += int(i[l])
    j -= 1

if abs(sumup - sumdown) <= k:
    print("YES")
else:
    print("NO")

print(abs(sumup - sumdown))