n = int(input())
for index in range(n):
    a = input()
    m = len(a) - 1
    a = int(a)
    for index1 in range(m, 0, -1):
        b = a % 10
        a /= 10
        if b >= 5:
            a += 1
    print(int(a) * (10 ** m))
        