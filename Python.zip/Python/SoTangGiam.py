t = int(input())
while t > 0:
    t -= 1
    s = input()
    l = len(s)
    m = 0
    for i in range(1, l):
        if s[i] < s[i - 1]:
            m = i
            break
        elif s[i] == s[i - 1]:
            m = -1
            break
    if m == -1:
        print("NO")
    else:
        for i in range(m, l):
            if s[i] >= s[i - 1]:
                m = -1
                break
        if m == -1:
            print("NO")
        else:
            print("YES")
            