n = int(input())
while n > 0:
    n -= 1
    a = input()
    l = len(a)
    if a[l - 2] == '8' and a[l - 1] == '6':
        print("YES")
    else:
        print("NO")