t = int(input())
dic = {}
while t > 0:
    t -= 1
    s = input()
    dic[s] = 1
print(len(dic))