


def Check(s):
    if s[0] == s[1] and s[1] == s[2] and s[2] == s[3]:
        return True
    return False

while True:
    s = list(map(int, input().split()))
    if s[0] == s[1] and s[1] == s[2] and s[2] == s[3] and s[3] == 0:
        break
    ii = 0
    while Check(s) == False:
        tmp = s[0]
        for i in range(3):
            s[i] = abs(s[i] - s[i + 1])
        s[3] = abs(s[3] - tmp)
        # print(s)
        ii += 1
    print(ii)
   