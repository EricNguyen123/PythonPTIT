import math


t = int(input())
while t > 0:
    t -= 1
    s = input()
    s = s.split(' ')
    a = float(s[2]) / float(s[0])
    b = float(1) + float(s[1]) / 100
    n = math.ceil(float(math.log(a, b)))
    print(n)