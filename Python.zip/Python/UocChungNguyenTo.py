import math

def gcd(a, b):
    while b != 0:
        tmp = a % b
        a = b
        b = tmp
    return a
def ktnt(a):
    if a == 1:
        return 0
    b = math.sqrt(a)
    b = int(b)
    for i in range(2,b + 1):
        if a % i == 0:
            return 0
    return 1
n = int(input())
while n > 0:
    n -= 1
    s = input()
    s = s.split(' ')
    a = int(s[0])
    b = int(s[1])
    # print(a ,b)
    if a < b:
        tmp = a
        a = b
        b = tmp
    c = gcd(a, b)
    # print(c)
    c = int(c)
    d = 0
    while c > 0:
        d = d + c % 10
        # print(c % 10)
        c /= 10
        c = int(c)
    # print(d)
    if ktnt(d) == 1:
        print('YES')
    else:
        print('NO')
    