class Matrix:
    def __init__(self, n, m, matrix):
        self.n = n
        self.m = m
        self.matrix = matrix
    def __str__(self):
        a = []
        for i in range(self.m):
            b = []
            for j in range(self.n):
                b.append(self.matrix[j][i])
            a.append(b)
        c = []
        for i in range(self.n):
            b = []
            for j in range(self.n):
                x = 0
                for k in range(self.m):
                    x += self.matrix[i][k] * a[k][j]
                b.append(str(x))
            c.append(b)
        res = ""
        for i in range(self.n):
            res += ' '.join(c[i]) + "\n"
        return res
t = int(input())
while t > 0:
    t -= 1
    a = list(map(int, input().split()))
    c = []
    for i in range(a[0]):
        b = list(map(int, input().split()))
        c.append(b)
    print(Matrix(a[0], a[1], c))
    