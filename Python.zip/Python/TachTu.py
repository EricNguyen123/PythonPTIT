s = input()
s = s.split()
for i in s:
    print(i)