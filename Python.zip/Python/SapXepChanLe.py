n = int(input())

# s = [int(m) for m in input().split()]
s =[]
while True:
    line = input().split()
    if line:
        for i in range(len(line)):
            s.append(int(line[i]))
        if len(s) == n:
            break
    else:
        break
a = []
b = []
for i in range(len(s)):
    s[i] = int(s[i])
    
for i in range(len(s)):
    if s[i] % 2 == 0:
        a.append(s[i])
    else:
        b.append(s[i])

a.sort()
b.sort(reverse=True)
x = y = 0
res = []
for i in range(len(s)):
    if s[i] % 2 == 0:
        res.append((a[x]))
        x += 1
    else:
        res.append((b[y]))
        y += 1
for i in range(len(s) - 1):
    print(res[i], end='')
    print(' ', end='')
print(res[len(s)- 1])
# print(' '.join(res))



        
        
