n = int(input())
while n > 0:
    n -= 1
    a = input()
    d = 0
    for i in a:
        if i != '0' and i != '1' and i != '2':
            d = 1
    if d == 0:
        print("YES")
    else:
        print("NO")