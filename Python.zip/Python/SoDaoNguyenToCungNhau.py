n = int(input())
def UCLN(a, b):
    while b != 0:
        tmp = a % b
        a = b
        b = tmp
    return a
while n > 0:
    n -= 1
    a = int(input())
    b = a
    c = 0
    while a > 0:
        c = c * 10 + a % 10
        a = int(a / 10)
    if b > c:
        tmp = b
        b = c
        c = tmp
    if UCLN(b, c) == 1:
        print("YES")
    else:
        print("NO")
    