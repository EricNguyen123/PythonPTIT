n = int(input())
while n > 0:
    n -= 1
    s = input()
    l = len(s)
    res = ""
    for i in range(1,l,2):
        x = int(s[i])
        while x > 0:
            x -= 1
            res += s[i - 1]
    print(res)
        
    