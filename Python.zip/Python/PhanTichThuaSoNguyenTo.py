import math



n = int(input())
while n > 0:
    n -= 1
    a = int(input())
    res = {}
    x = int(math.sqrt(a)) + 1
    for i in range(2, x):
        d = 0
        while a % i == 0:
            d += 1
            a /= i
            a = int(a)
        if d != 0:
            res[i] = d
    if a > 1:
        res[a] = 1
    s = ""
    for i in res:
        s += " * " + str(i) + "^" + str(res[i])
    s = "1" + s
    print(s)
        
        
        