


class Note:
    def __init__(self, a, b, c):
        x = list(a.split())
        x.reverse()
        self.a = a
        self.b = b
        self.c = c
        self.d = ""
        s = ' '.join(x)
        self.d += s
    def out(self):
        return self.a + ': ' + self.b + ' ' + self.c 
    

    
file1 = open("SOTAY.txt", 'r')
file2 = open("DIENTHOAI.txt", 'a')
d = 0
s = ""
date = ""
th = 0
note = []
for i in file1:
    x = i.split()
    if x[0] == "Ngay":
        date = x[1]
        d = 1
    if d == 1 and x[0] != "Ngay":
        s += i[:-1] + " "
        d += 1
    elif d == 2 and x[0] != "Ngay":
        s += i[:-1] + " " + date 
        v = s.split()
        a = ' '.join(v[:len(v) - 2])
        note.append(Note(a, v[len(v) - 2], v[len(v) - 1]))
        d = 1
        s = ""
note.sort(key=lambda x: x.d, reverse=False)
j = 0
for i in note:
    file2.write(i.out())
    if j != len(note) - 1:
        file2.write("\n")
    j += 1
file1.close()
file2.close()

        