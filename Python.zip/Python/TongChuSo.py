from curses.ascii import isdigit


t = int(input())
while t > 0:
    t -= 1
    s = input()
    a = []
    for i in range(len(s)):
        a.append(s[i])
    a.sort()
    res = ''
    sum = 0
    for i in range(len(a)):
        if str(a[i]).isdigit():
            sum += int(a[i])
        else:
            res += str(a[i])
            
    res += str(sum)
    print(res)
            
            