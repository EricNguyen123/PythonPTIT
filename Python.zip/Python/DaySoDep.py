t = int(input())
while t > 0:
    t -= 1
    n = int(input())
    s = list(map(int,input().split()))
    d = 0
    for i in range(1, len(s)):
        Min = min(s[i -1], s[i])
        Max = max(s[i - 1], s[i])
        while Max > 2 * Min:
            Min = 2 * Min
            d += 1
    print(d)
            