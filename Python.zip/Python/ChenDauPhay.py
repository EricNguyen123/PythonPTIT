s = input()
l = len(s)
res = ""
j = 0
if l % 3 == 2:
    res += s[0:2]
    j = 2
elif l % 3 == 1:
    res += s[0]
    j = 1
m = int(l / 3)
for i in range(m):
    res += "," + s[j:j + 3]
    j += 3
if l % 3 == 0:
    res = res[1:]
print(res)