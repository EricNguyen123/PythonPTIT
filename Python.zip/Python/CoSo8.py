s = input()
cd = {
    '000': '0',
    '001': '1',
    '010': '2',
    '011': '3',
    '100': '4',
    '101': '5',
    '110': '6',
    '111': '7'
}

if len(s) % 3 == 1:
    s = '00' + s
elif len(s) % 3 == 2:
    s = '0' + s
res = ''
l = int(len(s) / 3)
for i in range(l):
    v = s[i * 3: (i + 1) * 3]
    res += cd[v]
print(res)