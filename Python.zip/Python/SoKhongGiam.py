n = int(input())
while n > 0:
    n -= 1
    a = input()
    d = 0
    m = len(a)
    for i in range(1, len(a)):
        if int(a[i - 1]) > int(a[i]):
            d = 1
            break
    if d == 0:
        print("YES")
    else:
        print("NO")