
while True:
    n = int(input())
    if n == 0:
        break
    a = []
    while n > 0:
        n -= 1
        s = int(input())
        a.append(s)
    Max = max(a)
    Min = min(a)
    if Min == Max:
        print("BANG NHAU")
    else:
        print(str(Min) + " " + str(Max))
            
    