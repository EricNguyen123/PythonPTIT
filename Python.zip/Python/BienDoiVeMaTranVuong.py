n = list(map(int, input().split()))
a = []
for i in range(n[0]):
    a.append(list(map(int, input().split())))

if n[0] > n[1]:
    k = 0
    for i in range(n[0]):
        if (i + 1) % 2 == 1:
            a.remove(a[k])
            k += 1
            n[0] -= 1
            if n[0] == n[1]:
                break
elif n[0] < n[1]:
    for i in range(n[0]):
        x = n[1]
        k = 1
        for j in range(n[1]):
            if (j + 1) % 2 == 0:
                a[i].pop(k)
                k += 1
                x -= 1
                if x == n[0]:
                    break

for i in range(n[0]):
    for j in range(n[0]):
        print(a[i][j], end=" ")
    print()