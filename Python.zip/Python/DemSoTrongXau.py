from itertools import count


t = int(input())
while t > 0:
    t -= 1
    s = input()
    x = input()
    print(s.count(x, 0, len(s)))
