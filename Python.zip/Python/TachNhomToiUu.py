n, k = [int(x) for x in input().split()]
a = sorted([int(x) for x in input().split()])
s = 1
for i in range(1, n) :
    if a[i] - a[i - 1] > k :
        s += 1
print(s)