import math


t = int(input())
while t > 0:
    t -= 1
    s = list(map(int, input().split()))
    deta = 16 * (s[0] + s[1]) * (s[0] + s[1]) - 48 * s[0] * s[1]
    c1 = ((4*(s[0] + s[1]) - (math.sqrt(deta))) / (24))
    c2 = ((4*(s[0] + s[1]) + (math.sqrt(deta))) / (24))
    c = c1
    x = int(c * (s[0] - 2 * c) * (s[1] - 2 * c))
    c = c2
    y = int(c * (s[0] - 2 * c) * (s[1] - 2 * c))
    v1 = max(x , y)
    if v1 == x:
        c = c1
    else:
        c = c2
    a = []
    a.append(int((c + 1) * (s[0] - 2 * (c + 1)) * (s[1] - 2 * (c + 1))))
    a.append(int((c + 2) * (s[0] - 2 * (c + 2)) * (s[1] - 2 * (c + 2))))
    a.append(int((c - 1) * (s[0] - 2 * (c - 1)) * (s[1] - 2 * (c - 1))))
    a.append(int((c - 2) * (s[0] - 2 * (c - 2)) * (s[1] - 2 * (c - 2))))
    v2 = max(a)
    for i in range(len(a)):
        if a[i] == v2:
            a[i] = -1
    v3 = max(a)
    l = s[5]
    if s[5] % v1 != 0:
        l = int(s[5] / v1) * v1 + s[2]
    for i in range(l, s[6] + 1, v1):
        if i % v2 == s[3] and i % v3 == s[4]:
            print(i)
            break
    