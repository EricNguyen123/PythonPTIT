t = int(input())
fibonacci = []
def Fibonacci():
    fibonacci.append("0")
    fibonacci.append("1")
    fibonacci.append("1")
    for i in range(3, 93):
        fibonacci.append(str(int(fibonacci[i - 1]) + int(fibonacci[i - 2]))) 
Fibonacci()
while t > 0:
    t -= 1
    s = input().split()
    a = int(s[0])
    b = int(s[1]) + 1
    res = fibonacci[a:b]
    res = ' '.join(res)
    print(res)