t = int(input())
while t > 0:
    t -= 1
    n = int(input())
    a = list(map(int, input().split()))
    b = []
    for i in range(n):
        while len(b) > 0 and a[b[-1]] < a[i]: 
            b.pop()
        if len(b) == 0:
            print(i + 1, end=' ')
        else:
            print(i - b[-1], end=' ')
        b.append(i)
    print()