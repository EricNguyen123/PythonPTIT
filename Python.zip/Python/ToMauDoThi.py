import math


def addEdge(adj, v, w):      
    adj[v].append(w)
    adj[w].append(v)  
    return adj
def greedyColoring(adj, V):
      
    result = [-1] * V
    result[0] = 0
    available = [False] * V
    s = 0
    for u in range(1, V):
        for i in adj[u]:
            if (result[i] != -1):
                available[result[i]] = True
        cr = 0
        while cr < V:
            if (available[cr] == False):
                break     
            cr += 1
        result[u] = cr 
        s = max(s, cr)
        for i in adj[u]:
            if (result[i] != -1):
                available[result[i]] = False
    ccolor = {}
    for u in range(V):
        if result[u] in ccolor:
            ccolor[result[u]] += 1
        else:
            ccolor[result[u]] = 1
    res = 0
    x = ccolor.values()
    x = list(x)
    x.sort()
    s += 1
    for i in x:
        res += i * s
        s -= 1
    print(res)

      
t = int(input())
for j in range(t):
    t -= 1
    n = int(input())
    g1 = [[] for i in range(n)]
    x = list(map(int, input().split()))
    for i in range(1, len(x)):
        g1 = addEdge(g1, x[i] - 1, i)
    print("Case #", end='')
    print(j + 1, end=': ')
    greedyColoring(g1, n)