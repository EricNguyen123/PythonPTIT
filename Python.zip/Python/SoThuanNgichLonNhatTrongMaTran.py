import math

a = list(map(int, input().split()))
b = []
Max = 0
for i in range(a[0]):
    b.append(list(input().split()))
    for j in b[i]:
        if j == j[::-1] and len(j) > 1:
            Max = max(Max, int(j))

res = []
s = 0
for i in range(a[0]):
    for j in range(a[1]):
        if b[i][j] == str(Max):
            res.append([i, j])
            s += 1
if s == 0:
    print("NOT FOUND")
else:
    print(Max)
    for i in res:
        print("Vi tri ", end='[')
        print(i[0], end='][')
        print(i[1], end=']')
        print()
        