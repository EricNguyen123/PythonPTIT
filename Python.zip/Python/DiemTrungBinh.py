n = input()
s = input().split()
for i in range(len(s)):
    s[i] = float(s[i])
s = sorted(s)
Min = s[0]
Max = s[len(s) - 1]
res = []
for i in s:
    if i != Min and i != Max:
        res.append(i)

sum = 0
for i in res:
    sum += i

sum = round(float(sum / len(res)), 2)
print(sum)