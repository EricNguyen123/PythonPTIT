import math

a = list(map(int, input().split()))
b = []
Max = 0
Min = 10000000
for i in range(a[0]):
    b.append(list(map(int, input().split())))
    for j in b[i]:
        Max = max(Max, j)
        Min = min(Min, j)

res = []
s = 0
for i in range(a[0]):
    for j in range(a[1]):
        if b[i][j] == Max - Min:
            res.append([i, j])
            s += 1
if s == 0:
    print("NOT FOUND")
else:
    print(Max - Min)
    for i in res:
        print("Vi tri ", end='[')
        print(i[0], end='][')
        print(i[1], end=']')
        print()
        