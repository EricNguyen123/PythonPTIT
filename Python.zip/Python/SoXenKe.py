t = int(input())
while t > 0:
    t -= 1
    s = input()
    if len(s) % 2 == 1:
        if s[0] != s[1]:
            d = 0
            for i in range(2, len(s), 2):
                if s[i] != s[0]:
                    d = 1
                    break
            if d == 0:
                print("YES")
            else:
                print("NO")
        else:
            print("NO")
    else:
        print("NO")