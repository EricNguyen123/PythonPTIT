from curses.ascii import isalnum, isdigit
import math


t = int(input())
while t > 0:
    t -= 1
    s = input()
    res = 0
    v = ""
    for i in s:
        if isdigit(i):
            v += i
        else:
            if v != "":
                res = max(res, int(v))
                v = ""
    if v != "":        
        print(max(res, int(v)))
    else:
        print(res)