t = int(input())
while t > 0:
    t -= 1
    s = input()
    sum = 0
    for i in s:
        sum += int(i)
    sum = str(sum)
    if sum == sum[::-1] and len(sum) > 1:
        print("YES")
    else:
        print("NO")