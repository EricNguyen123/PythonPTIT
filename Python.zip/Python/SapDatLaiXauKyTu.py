t = int(input())
for ii in range(t):   
    a = input()
    b = input()
    c = {}
    d = {}
    for i in a:
        if i in c:
            c[i] += 1
        else:
            c[i] = 1
    for i in b:
        if i in d:
            d[i] += 1
        else:
            d[i] = 1
    x = 0
    if len(list(c)) == len(list(d)):
        for i in c:
            if i not in d or c[i] != d[i]:
                x = 1
                break
    else:
        x = 1
    if x == 0:
        print("Test " + str(ii + 1) + ": YES")
    else:
        print("Test " + str(ii + 1) + ": NO")
        
        