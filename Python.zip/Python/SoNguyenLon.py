from math import gcd


t = int(input())
while t > 0:
    t -= 1
    a = int(input())
    b = int(input())
    print(gcd(a, b))
    # while b != 0:
    #     tmp = a % b
    #     a = b
    #     b = tmp
    # print(a)
        