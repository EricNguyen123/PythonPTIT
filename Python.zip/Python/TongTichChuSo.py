t = int(input())
while t > 0:
    t -= 1
    s = input()
    l = len(s)
    sum = 0
    for i in range(1,l,2):
        sum += int(s[i])
    tich = 1
    d = e = 0
    for i in range(0,l,2):
        d += 1
        if s[i] != '0':
            tich *= int(s[i])
        else:
           e += 1
    if d == e:
        tich = 0
    print(str(tich) + " " + str(sum)) 