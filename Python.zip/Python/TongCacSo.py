t = int(input())
x = []
res = []
def XuLy(i, n, s):
    for j in range(i, 0, -1):
        s += j
        x.append(j)
        if s == n:
            res.append(x[:])
        elif s < n:
            XuLy(j, n, s)
        x.pop()
        s -= j

while t > 0:
    t -= 1
    a = int(input())
    x = []
    res = []
    XuLy(a, a, 0)
    print(len(res))
    for i in res:
        print("(", end='')
        for j in range(len(i) - 1):
            print(i[j], end=' ')
        print(i[len(i) - 1], end='')
        print(")", end=' ')
    print()
    
    
    