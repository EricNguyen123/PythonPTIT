s = input()
x = []
y = []
for i in range(len(s)):
    x.append(0)
    y.append(True)
def In():
    res = ''
    for i in x:
        res += s[i]
    print(res)
    
def HoanVi(i, n):
    for j in range(n):
        if y[j] == True:
            x[i] = j
            y[j] = False
            if i == n - 1:
                In()
            else:
                HoanVi(i + 1, n)
            y[j] = True

HoanVi(0, len(s))