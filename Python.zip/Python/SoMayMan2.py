n = int(input())
while n > 0:
    n -= 1
    a = input()
    d = 1
    for i in range(len(a)):
        if a[i] != '4' and a[i] != '7':
            d = 0
            break
    if d == 1:
        print('YES')
    else:
        print('NO')