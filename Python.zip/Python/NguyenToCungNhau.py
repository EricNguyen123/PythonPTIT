from re import I


def UCLN(a, b):
    while b != 0:
        tmp = a % b
        a = b
        b = tmp
    return a

s = input()
s = s.split()
n = int(s[0])
k = int(s[1])

a = 10 ** (k - 1)
b = 10 ** k
res = ""
d = 0
for i in range(a, b):
    c = i
    m = n
    if c > n:
        tmp = c
        c = m
        m = tmp  
    if UCLN(m, c) == 1:
        d += 1
        res += str(i) + " "
        if d == 10:
            print(res)
            res = ""
            d = 0
            
if d != 0:
    print(res)

