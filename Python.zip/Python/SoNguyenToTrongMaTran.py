import math
c = {}
for i in range(2, 1005):
    x = int(math.sqrt(i)) + 1
    d = 0
    for j in range(2, x):
        if i % j == 0:
            d = 1
            break
    if d == 0:
        c[i] = 1

a = list(map(int, input().split()))
b = []
Max = 0
for i in range(a[0]):
    b.append(list(map(int, input().split())))
    for j in b[i]:
        if j in c:
            Max = max(Max, j)


res = []
s = 0
for i in range(a[0]):
    for j in range(a[1]):
        if b[i][j] == Max and b[i][j] in c:
            res.append([i, j])
            s += 1
if s == 0:
    print("NOT FOUND")
else:
    print(Max)
    for i in res:
        print("Vi tri ", end='[')
        print(i[0], end='][')
        print(i[1], end=']')
        print()
        