import math


n = input()
s = input().split()
for i in range(len(s)):
    s[i] = int(s[i])

def KTNguyenTo(n):
    if n == 0 or n == 1:
        return False
    sqr = int(math.sqrt(n)) + 1
    for i in range(2, sqr):
        if n % i == 0:
            return False
    return True

dic = {}

for i in s:
    if KTNguyenTo(i) == True:
        # print(dic.keys())
        if i in dic.keys():
            dic[i] += 1
        else:
            dic[i] = 1

res = dic.items()

for i in res:
    print(str(i[0]) + " " + str(i[1]))
    