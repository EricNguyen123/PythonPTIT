t = int(input())
while t > 0:
    t -= 1
    n = int(input())
    s = input().split()
    v = input().split()
    for i in range(n):
        s[i] = int(s[i])
        v[i] = int(v[i])
    s = sorted(s)
    v = sorted(v)
    d = 0
    for i in range(n):
        if s[i] > v[i]:
            d = 1
            break
    if d == 0:
        print("YES")
    else:
        print("NO")