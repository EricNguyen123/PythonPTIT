import math


t = int(input())
def NguyenTo(n):
    if n == 0 or n == 1:
        return False
    for i in range(2, int(math.sqrt(n))):
        if n % i == 0:
            return False
    return True
while t > 0:
    t -= 1
    n = input()
    l = len(n)
    if NguyenTo(l):
        k = 0
        for i in n:
            if i == '2' or i == '3' or i == '5' or i == '7':
                k += 1
        if k > (l - k):
            print("YES")
        else:
            print("NO")
    else:
        print("NO")