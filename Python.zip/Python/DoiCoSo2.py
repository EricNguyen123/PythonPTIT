import math

c = ['A', 'B', 'C', 'D', 'E', 'F']
t = int(input())
while t > 0:
    t -= 1
    cs = int(input())
    s = input()
    mu = int(math.log(cs, 2))
    if cs == 2:
        print(s)
        continue
    while len(s) % mu != 0:
        s = '0' + s
    i = 0
    while i < len(s):
        tmp = 0
        for j in range(i, i + mu):
            tmp += int(s[j]) * (2 ** (mu - j + i - 1))
        if tmp < 10:
            print(tmp, end='')
        else:
            print(c[tmp - 10], end='')
        i += mu
    print()
    
    