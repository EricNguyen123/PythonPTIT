s = input()
# if s == s[::-1]:
#     print("YES")
# else:
#     print("NO")
print(len(s)-1)