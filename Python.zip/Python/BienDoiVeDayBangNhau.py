n = int(input())
a = [int(x) for x in input().split()]
s = 10**9
for i in a :
    x = 0
    for j in a :
        x += abs(i - j)
    if s > x :
        s = x
        p = i
print(s, p)