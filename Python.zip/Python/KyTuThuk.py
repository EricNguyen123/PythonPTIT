le = []
a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
def Lenght():
    le.append(0)
    le.append(1)
    for i in range(2, 26):
        le.append(le[i - 1] * 2 + 1)
def XuLy(n, k, Len):
    if k == Len[n - 1] + 1:
        return n
    elif k > Len[n - 1] + 1:
        return XuLy(n - 1, k - Len[n - 1] - 1, Len)
    else:
        return XuLy(n - 1, k, Len)
Lenght()
t = int(input())
while t > 0:
    t -= 1
    n, k = list(map(int, input().split()))
    x = XuLy(n, k, le)
    print(a[x - 1])
    