t = int(input())
while t > 0:
    t -= 1
    n = int(input())
    s = input().split()
    for i in range(len(s)):
        s[i] = int(s[i])
    Min = int(min(s))
    Max = int(max(s))
    a = {}
    for i in s:
        a[i] = 1
    res = (Max - Min + 1) - len(a)
    print(res)