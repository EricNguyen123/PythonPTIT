a = input()
print(a.upper())