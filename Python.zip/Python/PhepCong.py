
a = input()
if int(a[0]) + int(a[4]) == int(a[8]):
    print('YES')
else:
    print('NO')