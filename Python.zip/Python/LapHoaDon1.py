class HoaDon:
    MaKH = "KH"
    TenKH = ""
    SoCu = 0
    SoMoi = 0
    TongTien = 0
    def __init__(self, id, name, socu, somoi):
        self.MaKH += "{:02d}".format(id)
        self.TenKH = name
        self.SoCu = socu
        self.SoMoi = somoi
        x = somoi - socu
        if x <= 50:
            self.TongTien = x * 102
        elif x > 50 and x <= 100:
            self.TongTien = (50 * 100 + (x - 50) * 150) * 103 / 100
        elif x > 100:
            self.TongTien = (50 * 100 + 50 * 150 + (x - 100) * 200) * 105 / 100
    def __str__(self):
        res = ""
        res += self.MaKH + " " + self.TenKH + " " + str(round(self.TongTien))
        return res
t = int(input())
a = []
for i in range(t):
    name = input()
    socu = int(input())
    somoi = int(input())
    a.append(HoaDon(i + 1, name, socu, somoi))
a.sort(key=lambda x: x.TongTien, reverse=True)
for i in range(t):
    print(a[i])