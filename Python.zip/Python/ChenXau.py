x =input()
y = input()
n = int(input()) - 1
z = x[:n] + y + x[n:]
print(z)