s = 0
n = int(input())
a = [int(x) for x in input().split()]
for i in range(1, n) :
    if a[i] != a[i - 1] : s += 1
print(s)