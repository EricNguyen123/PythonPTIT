t = int(input())
while t > 0:
    t -= 1
    n = input()
    s = input().split()
    d = {}
    for i in s:
        d[i] = 0
    for i in s:
        d[i] += 1
    a = 0
    x = d.values()
    for i in x:
        a = max(a, i)
    if a > len(s) / 2:
        for i in d:
            if d[i] == a:
                print(i)
    else:
        print("NO")
    