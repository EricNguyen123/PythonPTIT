import math


n = int(input())
a = []
for i in range(n):
    a.append(list(map(int, input().split())))
k = int(input())
st = sd = 0
for i in range(n):
    for j in range(i + 1, n):
        st += a[i][j]
    for j in range(0, i):
        sd += a[i][j]
s = abs(st - sd)
if s <= k:
    print("YES")
    print(s)
else:
    print("NO")
    print(s)
    