import math


n = int(input())
b = []
c = []
for i in range(n):
    x = list(map(int, input().split()))
    b.append(x)
    c.append(1)
Max = 0
for j in range(1, n):
    for i in range(0, j):
        if b[j][0] > b[i][0] and b[j][1] > b[i][1]:
            c[j] = max(c[j], c[i] + 1)
    Max = max(Max, c[j])
print(Max)
    
    
