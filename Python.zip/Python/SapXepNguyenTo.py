


import math


def kt(n):
    m = int(math.sqrt(n) + 1)
    if n == 0 or n == 1:
        return False
    for i in range(2, m):
        if n % i == 0:
            return False
    return True
t = int(input())
x = list(map(int, input().split()))
a = []
for i in x:
    if kt(i) == True:
        a.append(i)
a.sort()
j = 0
for i in range(t):
    if kt(x[i]) == True:
        x[i] = a[j]
        j += 1
for i in  x:
    print(i, end=' ')
print()