import math


def KTChan(n):
    for i in range(0, len(n), 2):
        if int(n[i]) % 2 != 0:
            return False
    return True
def KTLe(n):
    for i in range(1, len(n), 2):
        if int(n[i]) % 2 == 0:
            return False
    return True
def KTNguyenTo(n):
    l = int(math.sqrt(n)) + 1
    for i in range(2, l):
        if n % i == 0:
            return False
    return True
def CheckSum(n):
    sum = 0
    for i in n:
        sum += int(i)
    if KTNguyenTo(sum) == True:
        return True
    return False

t = int(input())
while t > 0:
    t -= 1
    s = input()
    if KTChan(s) == True and KTLe(s) == True and CheckSum(s) == True:
        print("YES")
    else:
        print("NO")