from curses.ascii import isalnum, isdigit
import math


t = int(input())
while t > 0:
    t -= 1
    s = input()
    res = 1e18
    v = ""
    for i in s:
        if isdigit(i):
            v += i
        else:
            if v != "":
                res = min(res, int(v))
                v = ""
            
    print(res)
        