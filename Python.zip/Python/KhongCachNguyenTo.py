nt = []
for i in range(10005):
    nt.append(1)
nt[0] = nt[1] = 0
for i in range(2, 10005):
    j = i * 2
    while j < 10005:
        nt[j] = 0
        j += i
snt = []
for i in range(10005):
    if nt[i] == 1:
        snt.append(i)
s = input().split()
n = int(s[0])
x = int(s[1])

res = []
res.append(str(x))
for i in range(n):
    x += snt[i]
    res.append(str(x))
res = ' '.join(res)
print(res)
