import math


t = int(input())
def KTNguyenTo(n):
    if n == 0 or n == 1:
        return False
    sq = int(math.sqrt(n)) + 1
    for i in range(2, sq):
        if n % i == 0:
            return False
    return True
while t > 0:
    t -= 1
    s = input()
    sum = 0
    for i in s:
        if KTNguyenTo(int(i)):
            sum += int(i)
            # print(sum)
        else:
            sum = -1
            break
    if sum != -1:
        if KTNguyenTo(sum):
            if KTNguyenTo(int(s)):
                s = s[::-1]
                if KTNguyenTo(int(s)):
                    print("YES")
                else:
                    print("NO")
            else:
                print("NO")
        else:
            print("NO")
    else:
        print("NO")
        
            
    