t = int(input())
s = []
def giaiThua():
    x = 1
    s.append(1)
    for i in range(1, 10):
        x = x * i
        s.append(x)
giaiThua()
while t > 0:
    t -= 1
    a = input()
    x = 0
    for i in a:
        x += s[int(i)]
    if int(a) == x:
        print("Yes")
    else:
        print("No")
    
    
    