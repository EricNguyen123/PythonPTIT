t = int(input())
def Tong(x, y):
    while len(x) < len(y):
        x = "0" + x
    while len(x) > len(y):
        y = "0" + y
    x = x[::-1]
    y = y[::-1]
    s = ""
    nho = 0
    for i in range(len(x)):
        c = int(x[i]) + int(y[i]) + nho
        if c >= 10:
            s = str(c - 10) + s
            nho = 1
        else:
            s = str(c) + s
            nho = 0
    if nho > 0:
        s = str(nho) + s
    return s
    
def TongMax(a, b, c):
    x = ""
    for i in b:
        if i == a[0]:
            x += a[1]
        else:
            x += i
    b = x
    x = ""
    for i in c:
        if i == a[0]:
            x += a[1]
        else:
            x += i
    c = x
    s = Tong(b, c)
    return s
def TongMin(a, b, c):
    x = ""
    for i in b:
        if i == a[1]:
            x += a[0]
        else:
            x += i
    b = x
    x = ""
    for i in c:
        if i == a[1]:
            x += a[0]
        else:
            x += i
    c = x
    s = Tong(b, c)
    return s
while t > 0:
    t -= 1
    a = input()
    a = a.split(" ")
    if a[0] > a[1]:
        tmp = a[0]
        a[0] = a[1]
        a[1] = tmp
    s = input().split()
    if len(s) > 1:
        b = s[0]
        c = s[1]
    else:
        b = s[0]
        c = input()
    s1 = TongMax(a, b, c)
    s2 = TongMin(a, b, c)
    print(s2 + " " + s1)
        