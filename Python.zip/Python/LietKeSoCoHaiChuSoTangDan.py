n = input()
a = {}
for i in range(0, int(len(n)), 2):
    x = int(str(n[i:i+2]))
    if x not in a and len(str(x)) == 2:
        a[x] = 1
    elif x in a:
        a[x] += 1
# b = list(a.keys())
# # b.sort()
# c = list(map(str, b))
# print(' '.join(c))
    
b = list(a.items())
for i in b:
    print(str(i[0]) + ' ' + str(i[1]))