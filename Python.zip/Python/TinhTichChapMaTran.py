


# t = int(input())
# while t > 0:
#     t -= 1
#     s = input().split()
#     x = []
#     for i in range(int(s[0])): 
#         x.append(input().split())
#     h = []
#     for i in range(3):
#         h.append(input().split())
#     sum = 0
#     res = 0
#     s[0] = int(s[0]) - 2
#     s[1] = int(s[1]) - 2
#     for i in range(s[0]):
#         for j in range(s[1]):
#             for l in range(3):
#                 for m in range(3):
#                     sum += int(h[l][m]) * int(x[l + i][m + j])
#             res += sum
#             sum = 0
#     print(res)

t = int(input())
for z in range(t) :
    n, m = [int(x) for x in input().split()]
    a = [[0]] * n
    b = [[0]] * 3
    s = 0
    for i in range(n) : a[i] = [int(x) for x in input().split()]
    for i in range(3) : b[i] = [int(x) for x in input().split()]
    for i in range(2, n) :
        for j in range(2, m) :
            s += a[i - 2][j - 2] * b[0][0] 
            s += a[i - 2][j - 1] * b[0][1]
            s += a[i - 2][j] * b[0][2]
            s += a[i - 1][j - 2] * b[1][0]
            s += a[i - 1][j - 1] * b[1][1]
            s += a[i - 1][j] * b[1][2]
            s += a[i][j - 2] * b[2][0]
            s += a[i][j - 1] * b[2][1]
            s += a[i][j] * b[2][2]
    print(s)