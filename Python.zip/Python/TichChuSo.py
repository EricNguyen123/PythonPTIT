t = int(input())
while t > 0:
    t -= 1
    s = input()
    a = 1
    for i in s:
        if i != '0':
            a *= int(i)
    print(a)