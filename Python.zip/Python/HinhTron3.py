import math


s = float(input())
v = s / 8
a = math.sqrt(s)
b = math.sqrt(2 * a * a)
print('{:.4f}'.format(v/(2 * a + b)))