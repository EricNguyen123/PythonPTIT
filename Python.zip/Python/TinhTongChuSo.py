s = input()
d = 0

while len(s) != 1:
    d += 1
    sum = 0
    if s[0] != '-':
        sum += int(s[0])
    else:
        sum += ord('-') - ord('0')
    for i in range(1, len(s)):
        sum += int(s[i])
    s = str(sum)

print(d) 
