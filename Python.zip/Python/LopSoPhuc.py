from cgitb import reset


class SoPhuc:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def Tong(self, a):
        return SoPhuc(self.x + a.x, self.y + a.y)
    def Tich(self, a):
        b = self.x * a.x - self.y * a.y
        c = self.x * a.y + self.y * a.x
        return SoPhuc(b, c)
    def __str__(self):
        res = ""
        res += str(self.x)
        if self.y < 0:
            res += " - " + str(- self.y) + "i"
        else:
            res += " + " + str(self.y) + "i"
        return res
t = int(input())
while t > 0:
    t -= 1
    a = list(map(int, input().split()))
    x = SoPhuc(a[0], a[1]).Tong(SoPhuc(a[2], a[3]))
    print(x.Tich(SoPhuc(a[0], a[1])), end="") 
    print(", ", end="")
    print(x.Tich(x))
        
    