n = int(input())
while n > 0:
    n -= 1
    a = input()
    dau = a[0] + a[1]
    cuoi = a[len(a) - 2] + a[len(a) - 1]
    if dau == cuoi:
        print('YES')
    else:
        print('NO')