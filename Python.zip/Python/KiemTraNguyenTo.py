import math


def KTNguyenTo(n):
    if n == 0 or n == 1:
        return False
    sqr = int(math.sqrt(n)) + 1
    for i in range(2, sqr):
        if n % i == 0:
            return False
    return True

s = input().split()
x = int(s[0])
y = int(s[1])
a = []
for i in range(x):
    b = input().split()
    a.append(b)
# print(type(a[1][1]))

for i in range(x):
    for j in range(y):
        if KTNguyenTo(int(a[i][j])) == True:
            a[i][j] = '1'
        else:
            a[i][j] = '0'

for i in a:
    print(' '.join(i))