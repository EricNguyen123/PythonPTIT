t = int(input())
s = input().split()
d = 0
for i in range(t):
    for j in range(i + 1, t):
        if int(s[i]) > int(s[j]):
            d += 1
print(d)