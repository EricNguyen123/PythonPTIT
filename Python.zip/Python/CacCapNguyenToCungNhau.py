n = int(input())
s = input().split()
for i in range(len(s)):
    s[i] = int(s[i])
s = sorted(s)    

x = []
x.append(0)
for i in range(105):
    x.append(-1)   

def UCLN(a, b):
    while b != 0:
        tmp = a % b
        a = b
        b = tmp
    return a

def XuLy():
    v = [s[x[1] - 1], s[x[2] - 1]]
    v = sorted(v)
    if UCLN(v[1], v[0]) == 1:
        print(str(v[0]) + " " + str(v[1]))
    
def ToHop(st, a, b, x):
    for i in range(x[st - 1] + 1, b - a + st + 1):
        x[st] = i
        if st == a:
            XuLy()
        else:
            ToHop(st + 1, a, b, x)
            
ToHop(1, 2, n, x)