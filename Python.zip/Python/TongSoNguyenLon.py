


# a = input()
# b = input()
# c = ""
# a = a.lstrip('0')
# b = b.lstrip('0')
# m = len(a)
# n = len(b)
# a = a.rjust(n,'0')
# b = b.rjust(m,'0')
# nho = 0
# m = len(a)
# while m > 0:
#     s = int(a[m - 1]) + int(b[m - 1]) + nho
#     if s >= 10:
#         c = str(s - 10) + c
#         nho = 1
#     else:
#         c = str(s) + c
#         nho = 0
#     m -= 1
# if nho == 1:
#     c = "1" + c
# print(c)
a = int(input())
b = int(input())
print(a + b)