t = int(input())
while t > 0:
    t -= 1
    n = int(input())
    s = 0.000000
    n += 2
    if n % 2 == 0:
        for i in range(2, n, 2):
            s += 1 / i
    else:
        for i in range(1, n, 2):
            s += 1 / i
    s = "{:.6f}".format(s)
    print(s)
    