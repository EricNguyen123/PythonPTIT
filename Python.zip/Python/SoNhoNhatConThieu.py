t = int(input())
s = input().split()
for i in range(len(s)):
    s[i] = int(s[i])
s = sorted(s)
d = 0
for i in range(1, len(s)):
    if s[i] != s[i - 1] + 1:
        print(s[i - 1] + 1)
        d = 1
        break
if d == 0:
    print(s[len(s) - 1] + 1)