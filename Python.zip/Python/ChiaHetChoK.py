s = input()
s = s.split(' ')
x = int(s[2]) - int(s[0]) + 1
d = []
a = int(s[1]) - int(s[0]) % int(s[1])
for i in range(a, x, int(s[1])):
        d.append(i)
if len(d) == 0:
    print('-1')
else:
    print(*d)
        