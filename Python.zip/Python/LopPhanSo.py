
from math import gcd


class PhanSo:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __str__(self):
        ucln = gcd(self.x, self.y)
        return str(int(self.x / ucln)) + "/" + str(int(self.y / ucln))

a = list(map(int, input().split()))
b = PhanSo(a[0], a[1])
print(b)
