t = int(input())
while t > 0:
    t -= 1
    s = input().split('.')
    
    if len(s) != 4:
        print("NO")
        continue
   
    d = 0
    for i in range(len(s)):
        if s[i] > '255' or s[i] < '0':
            d = 1
            break
    if d == 0:
        print("YES")
    else:
        print("NO")