

n = int(input())
while n > 0:
    n -= 1
    s = input()
    l = len(s)
    res = ""
    a = s[0]
    b = 0
    for i in range(l):
        if s[i] == a:
            b += 1
        else:
            res += str(b) + a
            a = s[i]
            b = 1
    res += str(b) + a
    print(res)