a = input()
d = 0
for i in range(len(a)):
    if a[i] == '4' or a[i] == '7':
        d += 1
if d == 4 or d == 7:
    print('YES')
else:
    print('NO')