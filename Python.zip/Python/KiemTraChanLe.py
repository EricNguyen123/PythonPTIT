number = int(input())
if number % 2 == 0:
    print('CHAN')
else:
    print('LE')