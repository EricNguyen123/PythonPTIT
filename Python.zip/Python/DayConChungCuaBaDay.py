t = int(input())
while t > 0:
    t -= 1
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    c = list(map(int, input().split()))
    d = list(map(int, input().split()))
    x = y = z = 0
    res = []
    check = 0
    while x < a[0] and y < a[1] and z < a[2]:
        if b[x] == c[y] and c[y] == d[z]:
            res.append(str(b[x]))
            check = 1
            x = x + 1
            y = y + 1
            z = z + 1
        elif b[x] < c[y]:
            x += 1
        elif c[y] < d[z]:
            y += 1
        else:
            z += 1
    if check == 0:
        print("NO")
    else:
        print(' '.join(res))
            
    