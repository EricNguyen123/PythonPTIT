alien = input()
if alien == "green":
    print("the player earn 5 poin")
elif alien == "yellow":
    print("the player earn 10 poin")
else:
    print("the player earn 15 poin")