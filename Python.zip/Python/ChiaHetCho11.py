n = int(input())
while n > 0:
    n -= 1
    s = int(input())
    if s % 11 == 0:
        print("YES")
    else:
        print("NO")