n = int(input())
while n > 0:
    n -= 1
    a = input()
    l = len(a)
    d = 0
    for i in range(2, l, 2):
        if a[i - 2] != a[i]:
            d = 1
            break
    if d == 0:
        for i in range(3, l, 2):
            if a[i - 2] != a[i]:
                d = 1
                break 
        if d == 0:
            print("YES")
        
    if d == 1:
        print("NO")