import math


def KTNguyenTo(n):
    if n == 0 or n == 1:
        return False
    sqr = int(math.sqrt(n)) + 1
    for i in range(2, sqr):
        if n % i == 0:
            return False
    return True

t = int(input())
while t > 0:
    t -= 1
    s = input()
    dau = s[0:3]
    cuoi = s[len(s) - 3:len(s)]
    if KTNguyenTo(int(dau)) == True and KTNguyenTo(int(cuoi)):
        print("YES")
    else:
        print("NO")