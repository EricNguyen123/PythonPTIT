t = int(input())
while t > 0:
    t -= 1
    s = input().split()
    s[0] = int(s[0])
    s[1] = int(s[1])
    a = input().split()
    for i in range(s[0]):
        a[i] = int(a[i])
    Max = max(a)
    x = []
    y = []
    d = 0
    for i in range(s[0]):
        if a[i] < 0:
            x.append(str(a[i]))
        elif a[i] == Max and d == 0:
            y.append(str(s[1]))
            y.append(str(a[i]))
            d = 1
        else:
            y.append(str(a[i]))
    res = x + y
    Res = ' '.join(res)
    print(Res)
        
    