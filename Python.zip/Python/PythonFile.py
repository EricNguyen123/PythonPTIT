s = input()
s = s.lower()
v = s[-3:]
if v == '.py':
    print("YES")
else:
    print("NO")