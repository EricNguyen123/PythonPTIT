import math


t = int(input())
def KTNguyenTo(n):
    if n == 1 or n == 0:
        return False
    sqr = int(math.sqrt(n)) + 1
    for i in range(2, sqr):
        if n % i == 0:
            return False
    return True
def XuLy(n):
    for i in range(len(n)):
        if KTNguyenTo(i) == True:
            if n[i] != '2' and n[i] != '3' and n[i] != '5' and n[i] != '7':
                return False
        else:
            if n[i] == '2' or n[i] == '3' or n[i] == '5' or n[i] == '7':
                return False
    return True
while t > 0:
    t -= 1
    s = input()
    if XuLy(s) == True:
        print("YES")
    else:
        print("NO")