


s = list(map(int, input().split()))
a = []
module = 1e9 + 7
for i in range(s[0]):
    b = []
    for j in range(1, s[1] + 1):
        b.append((j + i * s[1]) % module)
    a.append(b)
    
# print(a)
while s[2] > 0:
    s[2] -= 1
    c = input().split()
    if c[0] == 'R':
        x = int(c[1]) - 1
        y = int(c[2])
        for i in range(s[1]):
            a[x][i] = y * a[x][i] % module
    elif c[0] == 'S':
        x = int(c[1]) - 1
        y = int(c[2])
        for i in range(s[0]):
            a[i][x] = y * a[i][x] % module

Sum = 0
for i in range(s[0]):
    Sum += sum(a[i]) % module
print(Sum)
        