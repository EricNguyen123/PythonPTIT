# print('Welcome to python.')
name = input()
print('Hello ' + name + '!')