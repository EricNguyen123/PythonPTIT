s = []
while True:
    line = input().split()
    if line:
        for i in range(len(line)):
            s.append(int(line[i]) % 42)
        if len(s) == 10:
            break
    else:
        break
r = []
l = 0
for i in s:
    d = 0
    for j in range(l):
        if r[j] == i:
            d = 1
            break
    if d == 0:
        r.append(i)
        l += 1
print(len(r))