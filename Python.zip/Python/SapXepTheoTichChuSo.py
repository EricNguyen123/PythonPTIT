t = int(input())
def Xuly(a, b):
    suma = sumb = 1
    for i in a:
        suma *= int(i)
    for i in b:
        sumb *= int(i)
    if suma == sumb:
        if int(a) > int(b):
            return True
        else:
            return False
    elif suma > sumb:
        return True
    else:
        return False
while t > 0:
    t -= 1
    n = input()
    s = input().split()
    for i in range(len(s)):
        for j in range( i + 1, len(s)):
            if Xuly(s[i], s[j]) == True:
                tmp = s[i]
                s[i] = s[j]
                s[j] = tmp
    s = ' '.join(s)
    print(s)