
from pickle import TRUE



def xuLy(s):
    if s == 1:
        return 1
    elif s % 2 == 0:
        return xuLy(s / 2) + 1
    elif s % 2 == 1:
        return xuLy(s * 3 + 1) + 1

while TRUE:
    n = int(input())
    if n == 0:
        break
    res = xuLy(n)
    print(res)
    