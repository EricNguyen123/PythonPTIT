t = int(input())
while t > 0:
    t -= 1
    a = input()
    if a[0] == a[-1]:
        print("YES")
    else:
        print("NO")