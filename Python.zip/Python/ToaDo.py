t = int(input())
while t > 0:
    t -= 1
    n = int(input())
    b = []
    for i in range(n):
        x = list(map(int, input().split()))
        b.append(x)
    b.sort(key=lambda x: x[1])
    d = 0
    v = 0
    
    for i in range(n):
        if d <= b[i][0]:
            d = b[i][1]
            v += 1
    print(v)
        