n = int(input())
x = {}
res = []
while n > 0:
    n -= 1
    s = list(map(int, input().split()))
    if s[2] == 1:
        x[s[0]] = 1
        x[s[1]] = 1
        
    elif s[2] == 2:
        if s[0] in x and s[1] in x:
            res.append(1)
        else:
            res.append(0)

for i in res:
    print(i)