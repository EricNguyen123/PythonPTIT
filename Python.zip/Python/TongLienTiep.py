import math


t = int(input())
def count(n):
    d = 0
    c = int(math.sqrt(n))
    l = r = 0
    x = y = 0
    for i in range(2, c + 1):
        if n % i == 0:
            x = n / i
            y = i
            if (y + x - 1) % 2 == 0:
                r = (y + x - 1) / 2
                l = x - r
                if l >= 1 and r > l:
                    d+= 1
    return d
while t > 0:
    t -= 1
    n = int(input())
    print(count(2 * n))
    
    